Create  Database EmlakProje

Create Table kisiler(
email nvarchar(50),
sifre nvarchar(50),
telno nvarchar(11),
yas nvarchar(3),
adsoyad nvarchar(50),
profilfoto nvarchar(255),
aciklama nvarchar(255),
rol nvarchar(50))

select * from kisiler
update kisiler set sifre ='Saffet.56' where email='saffetdmr7@gmail.com' 

Create Table ev(
Id nvarchar(50),
email nvarchar(50),
odasayisi nvarchar(10),
mkare nvarchar(10),
kirafiyat nvarchar(10),
satisfiyat nvarchar(50),
isitmaturu nvarchar(50),
esyali nvarchar(10),
binaturu nvarchar(50))

Create Table evfoto(
Id nvarchar(50),
evfoto1 nvarchar(255),
evfoto2 nvarchar(255),
evfoto3 nvarchar(255),
evfoto4 nvarchar(255),
evfoto5 nvarchar(255),
evfoto6 nvarchar(255),
evfoto7 nvarchar(255),
evfoto8 nvarchar(255),
evfoto9 nvarchar(255),
evfoto10 nvarchar(255),
email nvarchar(50))

Create Table evadres(
Id nvarchar(50),
sehir nvarchar(50),
ilce nvarchar(50),
mah nvarchar(50),
sokak nvarchar(50),
evno nvarchar(5),
kat nvarchar(3),
daireno nvarchar(4),
email nvarchar(50))

Create Table evlistele(
Id nvarchar(50),
sehir nvarchar(50),
ilce nvarchar(50),
mah nvarchar(50),
odasayisi nvarchar(10),
mkare nvarchar(10),
kiralikfiyat nvarchar(10),
satisfiyat nvarchar(50),
email nvarchar(50))


select * from kisiler
select * from ev
select * from evadres
select * from evlistele
select * from evfoto

select Max(Id) from ev
delete from evfoto
update ev set odasayisi='3+0',mkare='200',kirafiyat='10',satisfiyat='100',isitmaturu='saffet',esyali='evet',binaturu='normal' where Id = 2
select Id,sehir,ilce,mah,odasayisi,mkare,kiralikfiyat,satisfiyat from evlistele where email != 'saffetdmr7@gmail.com'
delete from evlistele where  Id > 0
select sehir,ilce,mah from evadres
select odasayisi,mkare,kirafiyat from ev
select * from ev where email = 'saffetdmr7@gmail.com'
select * from evadres where Id = '2'
select * from kisiler where rol = ''

insert into kisiler (email,sifre,telno,yas,adsoyad,profilfoto,aciklama,rol) values('admin','admin','05308326556','21','Saffet Demir','NULL','Software Engineer','admin')
insert into ev (Id,email,odasayisi,mkare,kirafiyat,satisfiyat,isitmaturu,esyali,binaturu) values ('2','saffetdmr7@gmail.com','4+2','190','500','50000','soba','e�yal�','m�stakil')
insert into evadres(Id,sehir,ilce,mah,sokak,evno,kat,daireno) values ('2','Siirt','Merkez','Alg�l','1105','11','2','1')
insert into evlistele (Id,sehir,ilce,mah,odasayisi,mkare,kiralikfiyat,satisfiyat,email) values ('2','Siirt','Merkez','Alg�l','4+2','190','50','50000','saffetdmr7@gmail.com')


Alter Table evlistele
ADD email nvarchar(50)

ALTER TABLE evadres ALTER COLUMN ilce nvarchar(50);